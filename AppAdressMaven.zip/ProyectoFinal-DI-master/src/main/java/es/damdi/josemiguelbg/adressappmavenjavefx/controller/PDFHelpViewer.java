package es.damdi.josemiguelbg.adressappmavenjavefx.controller;

import com.dansoftware.pdfdisplayer.PDFDisplayer;
import javafx.scene.Scene;
import javafx.stage.Modality;
import javafx.stage.Stage;

import java.io.File;
import java.io.IOException;
import java.net.URISyntaxException;
import java.net.URL;

/**
 * The type Pdf help.
 */
public class PDFHelpViewer {

    /**
     * Muestra el visor de PDF en una nueva ventana.
     *
     * @param ownerStage La ventana principal de la aplicación.
     * @throws IOException the io exception
     */
    public void showPdfViewer(Stage ownerStage) throws IOException {
        // Crear el visor PDF
        PDFDisplayer displayer = new PDFDisplayer();
        Scene scene = new Scene(displayer.toNode());

        // Cargar el PDF
        File pdfFile = loadPdf();
        if (pdfFile == null) {
            return; // Si no se pudo cargar, salir del método
        }

        displayer.loadPDF(pdfFile);

        // Crear una nueva ventana para mostrar el visor PDF
        Stage pdfStage = new Stage();
        pdfStage.initModality(Modality.WINDOW_MODAL);
        pdfStage.initOwner(ownerStage);
        pdfStage.setTitle("Ayuda - Manual de Usuario");
        pdfStage.setScene(scene);
        pdfStage.show();
    }

    /**
     * Carga el archivo PDF desde los recursos y devuelve un objeto File.
     * @return Un objeto File con el PDF cargado, o null si hay un error.
     */
    private File loadPdf() {
        // Obtener la URL del archivo PDF
        URL pdfUrl = getClass().getResource("C:\\Users\\zarag\\IdeaProjects\\ProyectoFinal-DI-master\\src\\main\\resources\\es\\damdi\\josemiguelbg\\adressappmavenjavefx\\help.html\\pdf\\prueba.pdf");
        if (pdfUrl == null) {
            System.err.println("⚠️ El archivo PDF no se encontró en el classpath.");
            return null;
        }

        try {
            // Convertir la URL en un archivo
            return new File(pdfUrl.toURI());
        } catch (URISyntaxException e) {
            System.err.println("❌ Error al cargar el archivo PDF: " + e.getMessage());
            return null;
        }
    }
}