package es.damdi.josemiguelbg.adressappmavenjavefx.controller;

import javafx.fxml.FXML;
import javafx.scene.Scene;
import javafx.scene.chart.LineChart;
import javafx.scene.chart.NumberAxis;
import javafx.scene.chart.XYChart;
import javafx.scene.layout.Pane;

/**
 * The type Line chart controller.
 */
public class LineChartController {
    @FXML
    private Pane paneView;
    @FXML
    private void initialize() {loadData();}

    private void loadData() {
        //defining the axes
        final NumberAxis xAxis = new NumberAxis();
        final NumberAxis yAxis = new NumberAxis();
        xAxis.setLabel("Number of Month");
        //creating the chart
        final LineChart<Number,Number> lineChart =
                new LineChart<Number,Number>(xAxis,yAxis);

        lineChart.setTitle("Stock Monitoring, 2010");
        //defining a series
        XYChart.Series series = new XYChart.Series();
        series.setName("Serie 1");
        //populating the series with data
        series.getData().add(new XYChart.Data(1, 22));
        series.getData().add(new XYChart.Data(2, 13));
        series.getData().add(new XYChart.Data(3, 14));
        series.getData().add(new XYChart.Data(4, 23));
        series.getData().add(new XYChart.Data(5, 33));
        series.getData().add(new XYChart.Data(6, 35));
        series.getData().add(new XYChart.Data(7, 21));
        series.getData().add(new XYChart.Data(8, 44));
        series.getData().add(new XYChart.Data(9, 42));
        series.getData().add(new XYChart.Data(10, 16));
        series.getData().add(new XYChart.Data(11, 28));
        series.getData().add(new XYChart.Data(12, 24));

        // Definir la segunda serie
        XYChart.Series series2 = new XYChart.Series();
        series2.setName("SErie2");
        series2.getData().add(new XYChart.Data(1, 29));
        series2.getData().add(new XYChart.Data(2, 17));
        series2.getData().add(new XYChart.Data(3, 24));
        series2.getData().add(new XYChart.Data(4, 27));
        series2.getData().add(new XYChart.Data(5, 39));
        series2.getData().add(new XYChart.Data(6, 32));
        series2.getData().add(new XYChart.Data(7, 26));
        series2.getData().add(new XYChart.Data(8, 49));
        series2.getData().add(new XYChart.Data(9, 40));
        series2.getData().add(new XYChart.Data(10, 21));
        series2.getData().add(new XYChart.Data(11, 33));
        series2.getData().add(new XYChart.Data(12, 29));

        // Crear la escena y agregar las series

        lineChart.getData().addAll(series, series2);
        paneView.getChildren().add(lineChart);
    }


}

