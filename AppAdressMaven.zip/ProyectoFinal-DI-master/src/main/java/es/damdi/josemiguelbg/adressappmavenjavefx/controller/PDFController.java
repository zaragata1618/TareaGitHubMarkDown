package es.damdi.josemiguelbg.adressappmavenjavefx.controller;

import com.dansoftware.pdfdisplayer.PDFDisplayer;
import javafx.fxml.FXML;
import javafx.scene.layout.AnchorPane;

import java.io.File;
import java.io.IOException;
import java.net.URISyntaxException;
import java.net.URL;

/**
 * The type Pdf controller.
 */
public class PDFController {

    /**
     * Instantiates a new Pdf controller.
     */
    public PDFController() {
        // Constructor vacío requerido por JavaFX
    }

    @FXML
    private AnchorPane pdfContainer;

    private PDFDisplayer pdfDisplayer;

    /**
     * Initialize.
     */
    @FXML
    public void initialize() {
        // Inicializar el visor de PDF
        pdfDisplayer = new PDFDisplayer();
        pdfContainer.getChildren().add(pdfDisplayer.toNode());
    }

    private File loadPdf() {
        // Obtener la URL del archivo PDF
        URL pdfUrl = getClass().getResource("C:\\Users\\zarag\\IdeaProjects\\ProyectoFinal-DI-master\\src\\main\\resources\\es\\damdi\\josemiguelbg\\adressappmavenjavefx\\help.html\\pdf\\prueba.pdf");
        if (pdfUrl == null) {
            System.err.println("⚠️ El archivo PDF no se encontró en el classpath.");
            return null;
        }

        try {
            // Convertir la URL en un archivo
            return new File(pdfUrl.toURI());
        } catch (URISyntaxException e) {
            System.err.println("❌ Error al cargar el archivo PDF: " + e.getMessage());
            return null;
        }
    }

    /**
     * Load pdf content.
     */
    public void loadPdfContent() {
        String markdownContent = String.valueOf(loadPdf());
        URL pdfUrl = getClass().getResource("/help/html/pdf/prueba.pdf");
        if (pdfUrl == null) {
            System.err.println("⚠️ El archivo PDF no se encontró en el classpath.");
            return;
        }
        try {
            File pdfFile = new File(pdfUrl.toURI());
            pdfDisplayer.loadPDF(pdfFile);
        } catch (URISyntaxException | IOException e) {
            System.err.println("❌ Error al cargar el archivo PDF: " + e.getMessage());
        }
    }
}
