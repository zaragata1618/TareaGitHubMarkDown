package es.damdi.josemiguelbg.adressappmavenjavefx.controller;

import javafx.scene.Scene;
import javafx.stage.Modality;
import javafx.stage.Stage;
import javafx.scene.control.Tooltip;
import javafx.scene.control.Button;
import javafx.scene.layout.VBox;

/**
 * The type Tool tip controller.
 */
public class TolltipController {

    /**
     * Muestra un botón con un Tooltip en una nueva ventana.
     *
     * @param ownerStage La ventana principal de la aplicación.
     */
    public void showToolTipViewer(Stage ownerStage) {
        // Crear el botón y el Tooltip
        Button button = new Button("Hover over me");
        Tooltip tooltip = new Tooltip(loadTooltipContent());
        button.setTooltip(tooltip);

        // Crear el layout y añadir el botón
        VBox layout = new VBox();
        layout.getChildren().add(button);

        // Crear la escena y asignarla al Stage
        Scene scene = new Scene(layout, 300, 200);

        // Crear una nueva ventana para mostrar el botón con Tooltip
        Stage toolTipStage = new Stage();
        toolTipStage.initModality(Modality.WINDOW_MODAL);
        toolTipStage.initOwner(ownerStage);
        toolTipStage.setTitle("ToolTip Demo");
        toolTipStage.setScene(scene);
        toolTipStage.show();
    }


    /**
     * Método para cargar el contenido del Tooltip.
     *
     * @return El contenido del Tooltip como String.
     */
    public String loadTooltipContent() {
        // Aquí puedes cargar texto desde un archivo o recurso.
        // Por ejemplo, podríamos cargar un archivo de texto o simplemente devolver un String fijo.

        // Simulando la carga del contenido del Tooltip desde un "recurso" (puede ser una URL, archivo, etc.)
        return "This is a helpful tooltip with loaded content.";
    }
}


