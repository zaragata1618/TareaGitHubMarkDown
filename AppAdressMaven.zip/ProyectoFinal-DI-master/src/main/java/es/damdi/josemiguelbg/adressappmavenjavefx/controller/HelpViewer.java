package es.damdi.josemiguelbg.adressappmavenjavefx.controller;

import com.vladsch.flexmark.html.HtmlRenderer;
import com.vladsch.flexmark.parser.Parser;
import com.vladsch.flexmark.util.ast.Node;
import javafx.fxml.FXML;
import javafx.scene.web.WebView;
import java.io.IOException;
import java.net.URISyntaxException;
import java.net.URL;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;

/**
 * The type Help viewer.
 */
public class HelpViewer {

    @FXML
    private WebView webView;

    /**
     * Load markdown content.
     */
    public void loadMarkdownContent() {
        String markdownContent = loadMarkdown();

        // Convertir Markdown a HTML
        Parser parser = Parser.builder().build();
        HtmlRenderer renderer = HtmlRenderer.builder().build();
        Node document = parser.parse(markdownContent);
        String htmlContent = renderer.render(document);

        // Cargar el HTML en el WebView
        webView.getEngine().loadContent(htmlContent);
    }

    private String loadMarkdown() {
        URL resourceUrl = getClass().getResource("C:\\Users\\zarag\\IdeaProjects\\ProyectoFinal-DI-master\\src\\main\\resources\\es\\damdi\\josemiguelbg\\adressappmavenjavefx\\help.html");
        if (resourceUrl == null) {
            System.err.println("⚠️ El archivo Markdown no se encontró en el classpath.");
            return "Error: No se pudo encontrar el archivo Markdown.";
        }
        try {
            Path path = Paths.get(resourceUrl.toURI());
            return Files.readString(path);
        } catch (IOException | URISyntaxException e) {
            System.err.println("❌ Error al cargar el archivo Markdown: " + e.getMessage());
            return "Error al cargar el archivo Markdown.";
        }
    }
}