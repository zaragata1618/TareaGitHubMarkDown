package es.damdi.josemiguelbg.adressappmavenjavefx.controller;

import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.fxml.FXML;
import javafx.scene.chart.PieChart;
import javafx.scene.layout.Pane;

/**
 * The type Pie chart controller.
 */
public class PieChartController {

    @FXML
    private Pane paneView;

    @FXML
    private void initialize() {
        loadData();
    }

    private void loadData() {
        ObservableList<PieChart.Data> pieChartData =
                FXCollections.observableArrayList(
                        new PieChart.Data("Grapefruit", 13),
                        new PieChart.Data("Oranges", 25),
                        new PieChart.Data("Plums", 10),
                        new PieChart.Data("Pears", 22),
                        new PieChart.Data("Apples", 30));

        // Crear el PieChart y establecer el título
        final PieChart chart = new PieChart(pieChartData);
        chart.setTitle("Imported Fruits");

        // Agregar el gráfico al pane
        paneView.getChildren().add(chart);
    }
}