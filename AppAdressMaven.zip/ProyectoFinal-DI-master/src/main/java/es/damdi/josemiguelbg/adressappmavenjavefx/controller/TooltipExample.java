package es.damdi.josemiguelbg.adressappmavenjavefx.controller;

import javafx.scene.Scene;
import javafx.stage.Modality;
import javafx.stage.Stage;
import javafx.scene.control.Tooltip;
import javafx.scene.control.Button;
import javafx.scene.layout.VBox;

import java.io.File;
import java.io.IOException;
import java.net.URISyntaxException;
import java.net.URL;

/**
 * The type Tool tip.
 */
public class TooltipExample {

    /**
     * Muestra un botón con un Tooltip en una nueva ventana.
     *
     * @param ownerStage La ventana principal de la aplicación.
     */
    public void showToolTipViewer(Stage ownerStage) {
        // Crear el botón y el Tooltip
        Button button = new Button("Hover over me");
        Tooltip tooltip = new Tooltip(loadTooltipContent());
        button.setTooltip(tooltip);

        // Crear el layout y añadir el botón
        VBox layout = new VBox();
        layout.getChildren().add(button);

        // Crear la escena y asignarla al Stage
        Scene scene = new Scene(layout, 300, 200);

        // Crear una nueva ventana para mostrar el botón con Tooltip
        Stage toolTipStage = new Stage();
        toolTipStage.initModality(Modality.WINDOW_MODAL);
        toolTipStage.initOwner(ownerStage);
        toolTipStage.setTitle("ToolTip Demo");
        toolTipStage.setScene(scene);
        toolTipStage.show();
    }

    /**
     * Método para cargar el contenido del Tooltip.
     * @return El contenido del Tooltip como String.
     */
    private String loadTooltipContent() {
        // Intentando cargar el contenido del Tooltip desde un recurso (puede ser archivo, URL, etc.)
        String tooltipText = loadTooltipFromResource();
        if (tooltipText == null) {
            tooltipText = "This is a default helpful tooltip with loaded content.";
        }
        return tooltipText;
    }

    /**
     * Método para cargar el contenido del Tooltip desde un recurso.
     * @return El contenido del Tooltip como String, o null si no se pudo cargar.
     */
    private String loadTooltipFromResource() {
        // Aquí puedes simular la carga de un archivo o un recurso
        URL resourceUrl = getClass().getResource("/help/html/tooltipContent.txt"); // Ruta del archivo
        if (resourceUrl == null) {
            System.err.println("⚠️ El archivo de contenido del Tooltip no se encontró en el classpath.");
            return null;
        }

        // Leer el archivo (puedes usar otras formas de cargar texto desde recursos)
        try {
            File file = new File(resourceUrl.toURI());
            return new String(java.nio.file.Files.readAllBytes(file.toPath())); // Devuelve el contenido del archivo
        } catch (IOException | URISyntaxException e) {
            System.err.println("❌ Error al cargar el archivo de contenido del Tooltip: " + e.getMessage());
            return null;
        }
    }
}
