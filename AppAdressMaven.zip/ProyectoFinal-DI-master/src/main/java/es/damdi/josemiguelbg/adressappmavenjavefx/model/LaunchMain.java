package es.damdi.josemiguelbg.adressappmavenjavefx.model;

import es.damdi.josemiguelbg.adressappmavenjavefx.MainApp;

/**
 * The type Launch main.
 */
public class LaunchMain {

    /**
     * The entry point of application.
     *
     * @param args the input arguments
     */
    public static void main(String[] args) {
        MainApp.main(args);
    }
}
