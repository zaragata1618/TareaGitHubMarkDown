package es.damdi.josemiguelbg.adressappmavenjavefx;

import java.io.*;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.prefs.Preferences;

import es.damdi.josemiguelbg.adressappmavenjavefx.controller.*;
import es.damdi.josemiguelbg.adressappmavenjavefx.model.Person;
import flexjson.JSONDeserializer;
import flexjson.JSONSerializer;
import javafx.application.Application;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.fxml.FXMLLoader;
import javafx.scene.Scene;
import javafx.scene.layout.AnchorPane;
import javafx.scene.layout.BorderPane;
import javafx.stage.FileChooser;
import javafx.stage.Modality;
import javafx.stage.Stage;
import org.kordamp.bootstrapfx.BootstrapFX;

/**
 * The type Main app.
 */
public class MainApp extends Application {

    /**
     * Instantiates a new Main app.
     */
    public MainApp() {
        // Add some sample data
        personData.add(new Person("Hans", "Muster"));
        personData.add(new Person("Ruth", "Mueller"));
        personData.add(new Person("Heinz", "Kurz"));
        personData.add(new Person("Cornelia", "Meier"));
        personData.add(new Person("Werner", "Meyer"));
        personData.add(new Person("Lydia", "Kunz"));
        personData.add(new Person("Anna", "Best"));
        personData.add(new Person("Stefan", "Meier"));
        personData.add(new Person("Martin", "Mueller"));
    }

    private Stage primaryStage;
    private BorderPane rootLayout;

    /**
     * The data as an observable list of Persons.
     */
    private ObservableList<Person> personData = FXCollections.observableArrayList();

    @Override
    public void start(Stage primaryStage) {
        this.primaryStage = primaryStage;
        this.primaryStage.setTitle("AddressApp Jose Miguel Berenguel Garcia");

        // this.primaryStage.getIcons().add(new Image(getClass().getResource("").toExternalForm()));


        initRootLayout();

        showPersonOverview();
    }

    /**
     * Initializes the root layout.
     */
    public void initRootLayout() {
        try {
            // Load root layout from fxml file.
            FXMLLoader loader = new FXMLLoader();
            loader.setLocation(MainApp.class.getResource("view/RootLayout.fxml"));
            rootLayout = (BorderPane) loader.load();

            RootLayoutController controller = loader.getController();
            controller.setMainApp(this);

            // Show the scene containing the root layout.
            Scene scene = new Scene(rootLayout);

            // scene.getStylesheets().add("css/modena_mod.css");
            scene.getStylesheets().add(BootstrapFX.bootstrapFXStylesheet());
            primaryStage.setScene(scene);
            primaryStage.show();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    /**
     * Shows the person overview inside the root layout.
     */
    /**
     * Shows the person overview inside the root layout.
     */
    public void showPersonOverview() {
        try {
            // Load person overview.
            FXMLLoader loader = new FXMLLoader();
            loader.setLocation(MainApp.class.getResource("view/PersonOverview.fxml"));
            AnchorPane personOverview = (AnchorPane) loader.load();

            // Set person overview into the center of root layout.
            rootLayout.setCenter(personOverview);

            // Give the controller access to the main app.
            PersonOverviewController controller = loader.getController();
            controller.setMainApp(this);

        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    /**
     * Returns the main stage.
     *
     * @return primary stage
     */
    public Stage getPrimaryStage() {
        return primaryStage;
    }

    /**
     * Opens a dialog to edit details for the specified person. If the user
     * clicks OK, the changes are saved into the provided person object and true
     * is returned.
     *
     * @param person the person object to be edited
     * @return true if the user clicked OK, false otherwise.
     */
    public boolean showPersonEditDialog(Person person) {
        try {
            // Load the fxml file and create a new stage for the popup dialog.
            FXMLLoader loader = new FXMLLoader();
            loader.setLocation(MainApp.class.getResource("view/PersonEditDialog.fxml"));
            AnchorPane page = (AnchorPane) loader.load();

            // Create the dialog Stage.
            Stage dialogStage = new Stage();
            dialogStage.setTitle("Edit Person");
            dialogStage.initModality(Modality.WINDOW_MODAL);
            dialogStage.initOwner(primaryStage);
            Scene scene = new Scene(page);
            //scene.getStylesheets().add("./css/modena_mod.css");
            scene.getStylesheets().add(BootstrapFX.bootstrapFXStylesheet());
            dialogStage.setScene(scene);

            // Set the person into the controller.
            PersonEditDialogController controller = loader.getController();
            controller.setDialogStage(dialogStage);
            controller.setPerson(person);

            // Show the dialog and wait until the user closes it
            dialogStage.showAndWait();

            return controller.isOkClicked();
        } catch (IOException e) {
            e.printStackTrace();
            return false;
        }
    }


    /**
     * Gets person data.
     *
     * @return the person data
     */
    public ObservableList<Person> getPersonData() {
        return personData;
    }


    /**
     * Returns the person file preference, i.e. the file that was last opened.
     * The preference is read from the OS specific registry. If no such
     * preference can be found, null is returned.
     *
     * @return person file path
     */
    public File getPersonFilePath() {
        Preferences prefs = Preferences.userNodeForPackage(MainApp.class);
        String filePath = prefs.get("filePath", null);
        if (filePath != null) {
            return new File(filePath);
        } else {
            return null;
        }
    }

    /**
     * Sets the file path of the currently loaded file. The path is persisted in
     * the OS specific registry.
     *
     * @param file the file or null to remove the path
     */
    public void setPersonFilePath(File file) {
        Preferences prefs = Preferences.userNodeForPackage(MainApp.class);
        if (file != null) {
            prefs.put("filePath", file.getPath());

            // Update the stage title.
            primaryStage.setTitle("AddressApp - " + file.getName());
        } else {
            prefs.remove("filePath");

            // Update the stage title.
            primaryStage.setTitle("AddressApp");
        }
    }

    /**
     * Save person data to file.
     *
     * @param file the file
     */
    public void savePersonDataToFile(File file) {
        JSONSerializer serializer = new JSONSerializer();

        // Convertimos personData en una lista de objetos simples
        List<Map<String, Object>> simplePersonList = new ArrayList<>();
        for (Person p : personData) {
            Map<String, Object> personMap = new HashMap<>();
            personMap.put("firstName", p.getFirstName());
            personMap.put("lastName", p.getLastName());
            personMap.put("street", p.getStreet());
            personMap.put("postalCode", p.getPostalCode());
            personMap.put("city", p.getCity());
            personMap.put("birthday", p.getBirthday());
            simplePersonList.add(personMap);
        }

        try (FileWriter writer = new FileWriter(file)) {
            String json = serializer.exclude("*.class").serialize(simplePersonList);
            writer.write(json);
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    /**
     * Load person data from file.
     *
     * @param file the file
     */
    public void loadPersonDataFromFile(File file) {
        JSONDeserializer<List<Map<String, Object>>> deserializer = new JSONDeserializer<>();

        try (BufferedReader reader = new BufferedReader(new FileReader(file))) {
            List<Map<String, Object>> loadedPersons = deserializer.deserialize(reader);

            personData.clear();
            for (Map<String, Object> personMap : loadedPersons) {
                Person p = new Person();
                p.setFirstName((String) personMap.get("firstName"));
                p.setLastName((String) personMap.get("lastName"));
                p.setStreet((String) personMap.get("street"));
                p.setPostalCode(((Number) personMap.get("postalCode")).intValue());
                p.setCity((String) personMap.get("city"));
                p.setBirthday(((Number) personMap.get("birthday")).intValue());
                personData.add(p);
            }
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    /**
     * Handle save as.
     */
    public void handleSaveAs() {
        FileChooser fileChooser = new FileChooser();

        // Configura la extensión del archivo
        FileChooser.ExtensionFilter extFilter = new FileChooser.ExtensionFilter(
                "Archivos JSON (*.json)", "*.json");
        fileChooser.getExtensionFilters().add(extFilter);

        // Muestra el diálogo de guardar archivo
        File file = fileChooser.showSaveDialog(primaryStage);

        if (file != null) {
            // Asegura que el archivo tenga la extensión correcta
            if (!file.getPath().endsWith(".json")) {
                file = new File(file.getPath() + ".json");
            }
            savePersonDataToFile(file);
        }
    }

    /**
     * Handle open.
     */
    public void handleOpen() {
        FileChooser fileChooser = new FileChooser();

        // Configura la extensión del archivo
        FileChooser.ExtensionFilter extFilter = new FileChooser.ExtensionFilter(
                "Archivos JSON (*.json)", "*.json");
        fileChooser.getExtensionFilters().add(extFilter);

        // Muestra el diálogo de abrir archivo
        File file = fileChooser.showOpenDialog(primaryStage);

        if (file != null) {
            loadPersonDataFromFile(file);
        }
    }

    /**
     * Show line chart boolean.
     *
     * @return the boolean
     */
    public boolean showLineChart() {
        try {
            // Load the FXML file and create a new stage for the popup dialog.
            FXMLLoader loader = new FXMLLoader();
            loader.setLocation(MainApp.class.getResource("view/LineChart.fxml"));
            AnchorPane page = (AnchorPane) loader.load();

            // Create the dialog Stage.
            Stage dialogStage = new Stage();
            dialogStage.setTitle("Line Chart");
            dialogStage.initModality(Modality.WINDOW_MODAL);
            dialogStage.initOwner(primaryStage);
            Scene scene = new Scene(page);

            // Cargar los estilos CSS de Bootstrap
            scene.getStylesheets().add(BootstrapFX.bootstrapFXStylesheet());

            dialogStage.setScene(scene);

            // Obtener el controlador del FXML para interactuar con él
            LineChartController controller = loader.getController();

            // Aquí puedes hacer más interacciones si es necesario, como pasar datos al controlador
            // Si el controlador necesita algo del MainApp, lo puedes hacer aquí.
            // controller.setMainApp(this); // Si es necesario

            // Show the dialog and wait until the user closes it
            dialogStage.show();

            return true;
        } catch (IOException e) {
            e.printStackTrace();
        }

        return false;
    }

    /**
     * Show bar chart boolean.
     *
     * @return the boolean
     */
    public boolean showBarChart() {
        try {
            // Load the FXML file and create a new stage for the popup dialog.
            FXMLLoader loader = new FXMLLoader();
            loader.setLocation(MainApp.class.getResource("view/BarChart.fxml"));
            AnchorPane page = (AnchorPane) loader.load();

            // Create the dialog Stage.
            Stage dialogStage = new Stage();
            dialogStage.setTitle("Bar Chart");
            dialogStage.initModality(Modality.WINDOW_MODAL);
            dialogStage.initOwner(primaryStage);
            Scene scene = new Scene(page);

            // Cargar los estilos CSS de Bootstrap
            scene.getStylesheets().add(BootstrapFX.bootstrapFXStylesheet());

            dialogStage.setScene(scene);

            // Obtener el controlador del FXML para interactuar con él
            BarChartController controller = loader.getController();

            // Aquí puedes hacer más interacciones si es necesario, como pasar datos al controlador
            // Si el controlador necesita algo del MainApp, lo puedes hacer aquí.
            // controller.setMainApp(this); // Si es necesario

            // Show the dialog and wait until the user closes it
            dialogStage.show();

            return true;
        } catch (IOException e) {
            e.printStackTrace();
        }

        return false;
    }

    /**
     * Show area chart boolean.
     *
     * @return the boolean
     */
    public boolean showAreaChart() {
        try {
            // Load the FXML file and create a new stage for the popup dialog.
            FXMLLoader loader = new FXMLLoader();
            loader.setLocation(MainApp.class.getResource("view/AreaChart.fxml"));
            AnchorPane page = (AnchorPane) loader.load();

            // Create the dialog Stage.
            Stage dialogStage = new Stage();
            dialogStage.setTitle("Area Chart");
            dialogStage.initModality(Modality.WINDOW_MODAL);
            dialogStage.initOwner(primaryStage);
            Scene scene = new Scene(page);

            // Cargar los estilos CSS de Bootstrap
            scene.getStylesheets().add(BootstrapFX.bootstrapFXStylesheet());

            dialogStage.setScene(scene);

            // Obtener el controlador del FXML para interactuar con él
            AreaChartController controller = loader.getController();

            // Aquí puedes hacer más interacciones si es necesario, como pasar datos al controlador
            // Si el controlador necesita algo del MainApp, lo puedes hacer aquí.
            // controller.setMainApp(this); // Si es necesario

            // Show the dialog and wait until the user closes it
            dialogStage.show();

            return true;
        } catch (IOException e) {
            e.printStackTrace();
        }

        return false;
    }


    /**
     * Show pie chart boolean.
     *
     * @return the boolean
     */
    public boolean showPieChart() {
        try {
            // Load the FXML file and create a new stage for the popup dialog.
            FXMLLoader loader = new FXMLLoader();
            loader.setLocation(MainApp.class.getResource("view/PieChart.fxml"));
            AnchorPane page = (AnchorPane) loader.load();

            // Create the dialog Stage.
            Stage dialogStage = new Stage();
            dialogStage.setTitle("Area Chart");
            dialogStage.initModality(Modality.WINDOW_MODAL);
            dialogStage.initOwner(primaryStage);
            Scene scene = new Scene(page);

            // Cargar los estilos CSS de Bootstrap
            scene.getStylesheets().add(BootstrapFX.bootstrapFXStylesheet());

            dialogStage.setScene(scene);

            // Obtener el controlador del FXML para interactuar con él
            PieChartController controller = loader.getController();

            // Aquí puedes hacer más interacciones si es necesario, como pasar datos al controlador
            // Si el controlador necesita algo del MainApp, lo puedes hacer aquí.
            // controller.setMainApp(this); // Si es necesario

            // Show the dialog and wait until the user closes it
            dialogStage.show();

            return true;
        } catch (IOException e) {
            e.printStackTrace();
        }

        return false;
    }

    /**
     * The entry point of application.
     *
     * @param
     */

    public void handleDocumentation() {
        try {
            // Cargar la interfaz para mostrar la documentación
            FXMLLoader loader = new FXMLLoader();
            loader.setLocation(getClass().getResource("view/HelpView.fxml"));
            AnchorPane page = loader.load();

            // Crear un nuevo Stage para mostrar la documentación
            Stage dialogStage = new Stage();
            dialogStage.setTitle("Documentación Técnica");
            dialogStage.initModality(Modality.WINDOW_MODAL);
            dialogStage.initOwner(primaryStage); // Ajustar esto si `primaryStage` no está disponible
            Scene scene = new Scene(page);
            dialogStage.setScene(scene);

            // Llamar al controlador de la vista y cargar el contenido Markdown
            HelpController helpController = loader.getController();
            helpController.loadMarkdownContent();

            dialogStage.show();

        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    /**
     * Handle mark down.
     */
    public void handleMarkDown() {
        try {
            // Cargar la interfaz para mostrar la documentación
            FXMLLoader loader = new FXMLLoader();
            loader.setLocation(getClass().getResource("view/MarkDown.fxml"));
            AnchorPane page = loader.load();

            // Crear un nuevo Stage para mostrar la documentación
            Stage dialogStage = new Stage();
            dialogStage.setTitle("Documentación Técnica");
            dialogStage.initModality(Modality.WINDOW_MODAL);
            dialogStage.initOwner(primaryStage); // Ajustar esto si `primaryStage` no está disponible
            Scene scene = new Scene(page);
            dialogStage.setScene(scene);

            // Llamar al controlador de la vista y cargar el contenido Markdown
            MarkDownController markDownController = loader.getController();
            markDownController.loadMarkdownContent();

            dialogStage.show();

        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    /**
     * Handle pdf help.
     */
    public void handlePdfHelp() {
        try {
            // Cargar la interfaz para mostrar el visor de PDF
            FXMLLoader loader = new FXMLLoader();
            loader.setLocation(getClass().getResource("view/Pdf.fxml"));
            AnchorPane page = loader.load();

            // Crear un nuevo Stage para mostrar el PDF
            Stage dialogStage = new Stage();
            dialogStage.setTitle("Manual de Usuario");
            dialogStage.initModality(Modality.WINDOW_MODAL);
            dialogStage.initOwner(primaryStage); // Ajustar esto si `primaryStage` no está disponible
            Scene scene = new Scene(page);
            dialogStage.setScene(scene);

            // Llamar al controlador de la vista y cargar el contenido del PDF
            PDFController pdfController = loader.getController();
            pdfController.loadPdfContent();

            dialogStage.show();

        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    /**
     * Handle tool tip.
     */
    public void handleToolTip() {
        try {
            // Cargar la interfaz para mostrar la documentación
            FXMLLoader loader = new FXMLLoader();
            loader.setLocation(getClass().getResource("view/ToolTip.fxml"));
            AnchorPane page = loader.load();

            // Crear un nuevo Stage para mostrar la documentación
            Stage dialogStage = new Stage();
            dialogStage.setTitle("Documentación Técnica");
            dialogStage.initModality(Modality.WINDOW_MODAL);
            dialogStage.initOwner(primaryStage); // Ajustar esto si `primaryStage` no está disponible
            Scene scene = new Scene(page);
            dialogStage.setScene(scene);

            // Llamar al controlador de la vista y cargar el contenido Markdown
            TolltipController toolTipController = loader.getController();
            toolTipController.loadTooltipContent();

            dialogStage.show();

        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    public static void main(String[] args) {
        launch(args);
    }

}
