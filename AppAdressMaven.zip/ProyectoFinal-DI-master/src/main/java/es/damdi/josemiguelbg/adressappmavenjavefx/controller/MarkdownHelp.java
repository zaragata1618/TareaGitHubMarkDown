package es.damdi.josemiguelbg.adressappmavenjavefx.controller;

import com.vladsch.flexmark.html.HtmlRenderer;
import com.vladsch.flexmark.parser.Parser;
import com.vladsch.flexmark.util.ast.Node;
import javafx.scene.Scene;
import javafx.scene.web.WebView;
import javafx.stage.Modality;
import javafx.stage.Stage;

import java.io.IOException;
import java.net.URISyntaxException;
import java.net.URL;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;

/**
 * The type Mark down help.
 */
public class MarkdownHelp {

    /**
     * Este método se encarga de cargar y mostrar la documentación Markdown.
     * Se invoca cuando se hace clic en "Documentación Técnica" en el menú.
     *
     * @param ownerStage El Stage principal que sirve de referencia para el nuevo Stage (popup).
     */
    public void showDocumentation(Stage ownerStage) {
        // Cargar el contenido del archivo Markdown
        String markdownContent = loadMarkdown();
        // Convertir Markdown a HTML utilizando Flexmark
        Parser parser = Parser.builder().build();
        HtmlRenderer renderer = HtmlRenderer.builder().build();
        Node document = parser.parse(markdownContent);
        String htmlContent = renderer.render(document);

        // Crear un WebView para mostrar el contenido HTML generado
        WebView webView = new WebView();
        webView.getEngine().loadContent(htmlContent);

        // Crear un Stage (ventana) para mostrar la documentación
        Stage documentationStage = new Stage();
        documentationStage.initModality(Modality.WINDOW_MODAL);
        documentationStage.initOwner(ownerStage);
        documentationStage.setTitle("Documentación Técnica");

        // Configurar la escena y mostrar la ventana
        Scene scene = new Scene(webView, 800, 600);
        documentationStage.setScene(scene);
        documentationStage.show();
    }

    /**
     * Método para cargar el contenido del archivo Markdown desde los recursos del classpath.
     *
     * @return Contenido del archivo Markdown como String, o un mensaje de error si ocurre un problema.
     */
    private String loadMarkdown() {
        // Obtener la URL del archivo Markdown en resources
        URL resourceUrl = getClass().getResource("C:\\Users\\zarag\\IdeaProjects\\ProyectoFinal-DI-master\\src\\main\\resources\\es\\damdi\\josemiguelbg\\adressappmavenjavefx\\help.html\\markdown\\readme.md");
        if (resourceUrl == null) {
            System.err.println("⚠️ El archivo Markdown no se encontró en el classpath.");
            return "Error: No se pudo encontrar el archivo Markdown.";
        }
        try {
            // Convertir la URL en una ruta válida para leer el archivo
            Path path = Paths.get(resourceUrl.toURI());
            return Files.readString(path); // Método más eficiente que `readAllBytes()`
        } catch (IOException | URISyntaxException e) {
            System.err.println("❌ Error al cargar el archivo Markdown: " + e.getMessage());
            return "Error al cargar el archivo Markdown.";
        }
    }
}