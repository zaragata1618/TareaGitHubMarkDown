module es.damdi.ismaelsg.adressappmavenjavefx {
    requires javafx.fxml;
    requires org.kordamp.bootstrapfx.core;
    requires java.prefs;
    requires flexjson;
    requires javafx.web;
    requires flexmark.util.ast;
    requires javafx.controls;
    requires flexmark;
    requires PDFViewerFX;
    requires javafx.graphics;


    opens es.damdi.josemiguelbg.adressappmavenjavefx to javafx.fxml;
    opens es.damdi.josemiguelbg.adressappmavenjavefx.controller;
    opens es.damdi.josemiguelbg.adressappmavenjavefx.model;
    exports es.damdi.josemiguelbg.adressappmavenjavefx;
}